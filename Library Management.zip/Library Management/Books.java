package library;

public class Books {

	private int BookId;
	private String BookName;
	private String BookAuthor;
	private double price;
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getBookAuthor() {
		return BookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		BookAuthor = bookAuthor;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Books(int bookId, String bookName, String bookAuthor, double price) {
		super();
		BookId = bookId;
		BookName = bookName;
		BookAuthor = bookAuthor;
		this.price = price;
	}
	public Books() {
		super();
	}
	@Override
	public String toString() {
		return "Books [BookId=" + BookId + ", BookName=" + BookName + ", BookAuthor=" + BookAuthor + ", price=" + price
				+ "]";
	}
	
	
	
	
}
