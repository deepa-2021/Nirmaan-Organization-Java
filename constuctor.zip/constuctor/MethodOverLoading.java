package day12;

import day11.employee;

public class MethodOverLoading {

public MethodOverLoading() {
	System.out.println("hello");
}
public MethodOverLoading(int num) {
	System.out.println(num);
}
public MethodOverLoading(String name) {
	System.out.println(name);
}
public MethodOverLoading(int num,String name) {
	
	System.out.println(num);
	System.out.println(name);
}
public static void main(String[]args) {
	MethodOverLoading a= new MethodOverLoading();
	
	employee em =new employee("deepa",11224,2000);
	System.out.println(em.getName());
	System.out.println(em.getId());
	System.out.println(em.getSalary());
	
}
}
