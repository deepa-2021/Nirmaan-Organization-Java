package day11;

public class employee {
	
private String name;
private int id;
private double salary;


public employee() {
	
}


public employee(String name,int id,double salary) {
	this.name=name;
	this.id=id;
	this.salary=salary;
	
}

public void setname(String employeename) {
    name=employeename;
	
}
public String getName() {
	return name;
	
	
}
public void setId(int employeeid) {
	id=employeeid;
}
public int getId() {
	return id;
}

public void setSalary(double employeesalary) {
	salary=employeesalary;
}
public double getSalary() {
	return salary;
}



}
