package day9;

public class calculator {
	
	void add(int num1,int num2) {
	System.out.println("addition:"+(num1+num2));	
}
	void sub(int num1, int num2) {
	System.out.println("substraction:"+(num1-num2));
	}
	
	void multi(int num1,int num2) {
	System.out.println("multiplicatio:"+(num1*num2));	
	}
	
	void div(int num1,int num2) {
	System.out.println("division:"+(num1/num2));	
	}
	
	void mod( int num1,int num2) {
	System.out.println("modules:"+(num1%num2));	
	}
	

}
