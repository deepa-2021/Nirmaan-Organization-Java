package day9;
import java.util.Scanner;

public class UI {
	
public static void main(String[]args) {
	
Scanner sc= new Scanner(System.in);
System.out.println("enter the first number");
int number1=sc.nextInt();
System.out.println("enter the second number");
int number2=sc.nextInt();


calculator calc=new calculator();

calc. add(number1,number2);
calc. sub(number1,number2);
calc.multi(number1, number2);
calc.div(number1, number2);
calc.mod(number1, number2);
}

}
