package day21;

import java.util.ArrayList;
import java.util.Scanner;

public class UIinterface {
	
	public static void main(String[] args) {
		ArrayList<Book> books=new ArrayList<Book>();
		Scanner sc=new Scanner(System.in);
		Service service=new Service();
		Book book=new Book();
		while(true) {
			System.out.println("enter the key \n 1 for add book \n 2 for  get book\n 3 getbook by id \n 4 for put book\n 5  for delete book" );
			int key=sc.nextInt();
			
			 if(key==1) {
				 Book newbook=service.addBook();
				books.add(newbook);
			 }
			 else if(key==2) {
				 
				 service.getBooks(books);
				 
				 
				 
			 }
			 else if(key==3) {
				 System.out.println("enter the book id:");
				 int id=sc.nextInt();
				 System.out.println(service.getBook(books,id));
				 
			 }
			 else if(key==4) {
				 service.PutBook(books);
				 
			 }
			 else if(key==5) {
				 service.DeleteBook(books);
				 
			 }
			 
			
		
		}
		
		
		
	}

}
