package day21;

import java.util.ArrayList;
import java.util.Scanner;

public class Service {
	Scanner sc = new Scanner(System.in);

	public Book addBook() {

		System.out.println("enter the id");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("enter the bookname");
		String bookname = sc.nextLine();
		System.out.println("enter the author name");
		String authorname = sc.nextLine();
		System.out.println("enter the price");
		double price = sc.nextDouble();

		Book book = new Book(id, bookname, authorname, price);

		return book;
	}

	public void getBooks(ArrayList<Book> books) {
		System.out.println(books);
	}

	public Book getBook(ArrayList<Book> books, int id) {
		for (Book book : books) {
			if (book.getId() == id) {
				return book;
			}
		}

		return null;
	}

	public ArrayList<Book> PutBook(ArrayList<Book> books) {
		System.out.println("enter the book id for update:");
		int id = sc.nextInt();
		sc.nextLine();
		for (Book book : books) {
			if (book.getId() == id) {
				System.out.println("enter the book name:");
				String bookName = sc.nextLine();
				System.out.println("enter the author name:");
				String authorname = sc.nextLine();
				System.out.println("enter the price:");
				double price = sc.nextDouble();
				book.setBookname(bookName);
		
				book.setAuthorname(authorname);
				book.setPrice(price);

			}
		}
		return books;

	}

	public ArrayList<Book> DeleteBook(ArrayList<Book> books) {
		System.out.println("enter the book id fr delete:");
		int id = sc.nextInt();
		for(Book book:books) {
			if(id==book.getId()) {
				books.remove(book);
				return books;
			}
		}
		return books;
	}
	

			
		

	}


