package day21;

public class Book {
	
private int id;
private String bookname;
private String authorname;
private double price;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getAuthorname() {
	return authorname;
}
public void setAuthorname(String authorname) {
	this.authorname = authorname;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public Book(int id, String bookname, String authorname, double price) {
	super();
	this.id = id;
	this.bookname = bookname;
	this.authorname = authorname;
	this.price = price;
}
public Book() {
	super();
}
@Override
public String toString() {
	return "Library [id=" + id + ", bookname=" + bookname + ", authorname=" + authorname + ", price=" + price + "]";
}



}



